# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 15:09:20 2021

@author: Lauren.Gilbert
"""

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC 
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import time
import os
import time
import shutil, os
import datetime
import win32com.client as win32
from selenium.webdriver.common.by import By 
import sys
import getpass
import pandas as pd
import xlrd
from collections import OrderedDict
import json as simplejson
import json
import requests
import webbrowser 


#LinksDf=pd.read_csv(os.getcwd()+"\links-WK.csv")
LinksDf=pd.read_csv(r'C:\Users\Lauren.Gilbert\OneDrive - Unilever\Apprentice\Ethan Take Over\PBI Weekly Stats\links-WK.csv')
Market=LinksDf["Market"].tolist()
links=LinksDf["Links"].tolist()

user="lauren.gilbert@unilever.com"
driver = webdriver.Chrome(ChromeDriverManager().install())
driver.maximize_window()
Df_Summary=pd.DataFrame()

for m,l in zip(Market,links):
    print(m)
    
    path=r"C:\Users\\"+getpass.getuser()+"\downloads\\"
    if os.path.exists(path+'data.xlsx'):
      os.remove(path+'data.xlsx')
    else:
      print("The file does not exist")
      
      driver.get(l)
    time.sleep(10)
    try:
         driver.find_element_by_xpath("//a[@class='button']").click()
         username=driver.find_element_by_xpath('//*[@id="i0116"]')
         username.send_keys(user)
         Export_select = WebDriverWait(driver, 60).until(
                    EC.element_to_be_clickable((By.XPATH, '//*[@id="idSIButton9"]')))
         Export_select.click() 
    
         time.sleep(30)
    except:
        pass
   
    #time.sleep(300)

    
    
    #//div[@class='vcBody themableBackgroundColor themableBorderColorSolid ng-star-inserted']
    try:
        a=driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container[1]/transform/div/div[3]/div/visual-modern/div/div/div[2]/div[1]/div[6]/div/div/div[1]/div')
    except:
        a=driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/div[3]/div/visual-modern/div/div/div[2]/div[1]/div[6]/div/div/div[1]/div')
        
    a.click()
    time.sleep(2)
    try:
        driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container[1]/transform/div/visual-container-header/div/div[1]/div/visual-container-options-menu/visual-header-item-container/div/button').click()
    except:
        driver.find_element_by_xpath('//*[@id="pvExplorationHost"]/div/div/exploration/div/explore-canvas-modern/div/div[2]/div/div[2]/div[2]/visual-container-repeat/visual-container-modern[1]/transform/div/visual-container-header-modern/div/div[1]/div/visual-container-options-menu/visual-header-item-container/div/button').click()
    
    ExportData_select = WebDriverWait(driver, 60).until(
                    EC.element_to_be_clickable((By.XPATH, '//h6[contains(text(),"Export data")]')))
    ExportData_select.click()
    
    time.sleep(2)
    Export_select = WebDriverWait(driver, 60).until(
                    EC.element_to_be_clickable((By.XPATH, '//button[contains(text(),"Export")]')))
    Export_select.click()
    time.sleep(30)
    
    
driver.close()